importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(oMessage) {
    var oBody = String(oMessage.getBody(new java.lang.String().getClass())),
    sRows = oBody.split("\n"),
    FileControl = {},
    FirmControl = {},
    FormsList = [],
    record = {},
    record1 = {},
    Detail = [],
    i = 0,
    j = 0,
    Header = {};
    
    
    var oHeaders = oMessage.getHeaders();
    var CamelFileNameOnly = oHeaders.get("CamelFileNameOnly");

    // if(CamelFileNameOnly.includes("cba")){
    //     Header.isAdvances = "1"; // Advance file
    // }else{
    //     Header.isAdvances = "0"; // Invoice file
    // }

    FileControl.FirmNumber = sRows[0].substring(0, 6).toString();
    FileControl.CBADate = (sRows[0].substring(6, 10).toString() +'-'+ sRows[0].substring(10, 12).toString() + '-' +sRows[0].substring(12, 14).toString());
    FileControl.RecordType = sRows[0].substring(14, 15).toString();
    FileControl.ClaimNumber = sRows[0].substring(15, 23).toString();
    FileControl.RecIdentification = sRows[0].substring(23, 27).toString();
    FileControl.TotalRecordsCount = sRows[0].substring(27, 32).toString();
    FileControl.TotalFirmsCount = sRows[0].substring(32, 38).toString();
    FileControl.TotalBenefitAmount = sRows[0].substring(38, 53).toString();

    for (i = 1; i < sRows.length; i++) {
        sRows[i] = sRows[i].trim();
        if(sRows[i].length === 50){
            FirmControl.FirmNumber = sRows[i].substring(0, 6).toString();
            FirmControl.CBADate = (sRows[i].substring(6, 10).toString() +'-'+ sRows[1].substring(10, 12).toString() + '-' +sRows[1].substring(12, 14).toString());
            FirmControl.RecordType = sRows[i].substring(14, 15).toString();
            FirmControl.ClaimNumber = sRows[i].substring(15, 23).toString();
            FirmControl.RecIdentification = sRows[i].substring(23, 27).toString();
            FirmControl.CBAAmount = sRows[i].substring(27, 43).toString();
            FirmControl.NumberofRecord = sRows[i].substring(43, 50).toString();
        }
        if(sRows[i].length === 217){
            record = {};
            record.FirmNumber = sRows[i].substring(0, 6).toString();
            record.CBADate = (sRows[i].substring(6, 10).toString() +'-'+ sRows[i].substring(10, 12).toString() + '-' +sRows[i].substring(12, 14).toString());
            record.RecordType = sRows[i].substring(14, 15).toString();
            record.ClaimNumber = sRows[i].substring(15, 23).toString();
            record.RecIdentification = sRows[i].substring(23, 27).toString();
            record.Name = sRows[i].substring(27,52).toString();
            record.AddressLine1 = sRows[i].substring(52,77).toString();
            record.AddressLine2 = sRows[i].substring(77,102).toString();
            record.AddressLine3 = sRows[i].substring(102,127).toString();
            record.AddressLine4 = sRows[i].substring(127,152).toString();
            record.AddressLine5 = sRows[i].substring(152,177).toString();
            record.PostCode = sRows[i].substring(177,184).toString();
            record.BenefitType = sRows[i].substring(184,185).toString();
            record.Special = sRows[i].substring(185,186).toString();
            record.Award = sRows[i].substring(186,187).toString();
            // record.HealthCareNo = sRows[i].substring(50,55).toString();
            record.DatePaidTo = (sRows[i].substring(187,191).toString() +'-'+ sRows[i].substring(191,193).toString() + '-' +sRows[i].substring(193,195).toString());
            record.ProcessingDate = (sRows[i].substring(195,199).toString() +'-'+ sRows[i].substring(199,201).toString() + '-' +sRows[i].substring(201,203).toString());
            record.BenefitAmount = sRows[i].substring(203,217).toString();
            Detail.push(record);
        }

        if(i === sRows.length - 1){
            record1.FirmControl=FirmControl;
            record1.Detail = Detail;
            FormsList.push(record1);
            Detail = [];
            FirmControl = {};
            record1 = {};
        }else if(50 === sRows[i+1].trim().length){
            record1.FirmControl=FirmControl;
            record1.Detail = Detail;
            FormsList.push(record1);
            Detail = [];
            FirmControl = {};
            record1 = {};
        }
    }

    oMessage.setBody(
    JSON.stringify({
        FileControl: FileControl,
        FormsList: FormsList,
        // Header: Header,
    }));
    oMessage.setHeader("Content-Type", "application/json");
  
    var oMessageLog = messageLogFactory.getMessageLog(oMessage);
    if (oMessageLog !== null) {
        // oMessageLog.addAttachmentAsString("Weekly File",oBody,"text/plain");
        oMessageLog.addCustomHeaderProperty("File Name", CamelFileNameOnly);
    }

    return oMessage;
}
