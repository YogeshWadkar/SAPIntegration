import com.sap.gateway.ip.core.customdev.util.Message
import javax.mail.util.ByteArrayDataSource
import java.util.HashMap
import groovy.json.*
import com.sap.gateway.ip.core.customdev.util.AttachmentWrapper

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    def sBody = message.getBody(java.lang.String);
    def oBodyJson = {};
    def ATTACHMENTS = '';
    def oJsonSlurper = new JsonSlurper();
    def oJsonOutput = new JsonOutput();

    message.setProperty('TO', '');
    message.setProperty('CC', '');
    message.setProperty('SUBJECT', '');
    message.setProperty('BODY', '');
    if (sBody != '') {
        oBodyJson = oJsonSlurper.parseText(sBody);
        message.setProperty('TO', oBodyJson.TO);
        message.setProperty('CC', oBodyJson.CC);
        message.setProperty('SUBJECT', oBodyJson.SUBJECT);
        message.setProperty('BODY', oBodyJson.BODY);

        ATTACHMENTS = oBodyJson.ATTACHMENTS;
        if (ATTACHMENTS != null && !ATTACHMENTS.isEmpty()) {
            for (oObject in ATTACHMENTS) {
                oDataSource = new ByteArrayDataSource(oObject.ATTACHMENT.decodeBase64(), 'Application/Octet-Stream');
                oAttachment = new AttachmentWrapper(oDataSource);
                message.addAttachmentObject(oObject.FILENAME, oAttachment);
            }
        }
    }
    return message
}