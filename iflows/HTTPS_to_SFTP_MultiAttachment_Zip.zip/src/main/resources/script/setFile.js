importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var sBody = String(message.getBody(new java.lang.String().getClass())),
    oBody = JSON.parse(sBody),
    RouteFlag = 0;

  if ("Content" in oBody) {
    message.setBody(oBody.Content);
    RouteFlag = 1;
  } else if ("ObjectId" in oBody) {
    message.setProperty("ObjectId", oBody.ObjectId);
    RouteFlag = 2;
  }

  message.setProperty("RouteFlag", RouteFlag);
  message.setHeader("CamelFileName", oBody.FileName);

  return message;
}
