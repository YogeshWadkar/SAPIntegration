importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var sBody = String(message.getBody(new java.lang.String().getClass())),
    oMessageLog = messageLogFactory.getMessageLog(message),
    oBody = JSON.parse(sBody),
    ErrorFlag = "1";

  if ("ZipName" in oBody) {
    message.setProperty("ZipName", oBody.ZipName || "DefaultName.zip");
    ErrorFlag = "0";
  } else {
    ErrorFlag = "1";
  }

  if (
    "Files" in oBody &&
    typeof oBody.Files === "object" &&
    oBody.Files.length >= 1
  ) {
    ErrorFlag = "0";
  } else {
    ErrorFlag = "1";
  }

  message.setProperty("ErrorFlag", ErrorFlag);

//   if (oMessageLog != null) {
//     oMessageLog.addAttachmentAsString(
//       "Inbound Payload:",
//       JSON.stringify(oBody, null, 4),
//       "application/json"
//     );
//   }
  return message;
}
